import { Route, BrowserRouter as Router, Routes } from "react-router-dom";

import GNB from "@/components/GNB";
import { NotFound } from "@/pages/NotFound";
import Dashboard from "./pages/Dashboard";
import { Logs } from "./pages/Logs";
import { Setting } from "./pages/Setting";

function App() {
  return (
    <div>
      <Router>
        <GNB />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/logs" element={<Logs />} />
          <Route path="/setting" element={<Setting />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
