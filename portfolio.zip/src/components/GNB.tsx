import { Link } from "react-router-dom";

export default function GNB() {
  return (
    <nav className="px-10 border-b">
      <Link to="/" className="p-5">
        Dashboard
      </Link>
      <Link to="/category2" className="p-5">
        CATEGORY 2
      </Link>
    </nav>
  );
}
