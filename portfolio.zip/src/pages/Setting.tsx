import { PageLayout } from "@/components/PageLayout";
import { Outlet, useLocation } from "react-router-dom";

export const Setting = () => {
  const location = useLocation();
  return (
    <PageLayout>
      <h1 className="text-2xl font-bold">🧠 {location.pathname}</h1>
      <p className="mt-2 text-gray-600">이 페이지는 🧠 {location.pathname} 페이지 템플릿입니다.</p>
      <Outlet />
    </PageLayout>
  );
};
