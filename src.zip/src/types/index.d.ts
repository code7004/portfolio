// @types/index.d.ts
/// <reference path="./globals.d.ts" />
